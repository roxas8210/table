<template>
    <tbody>
        <tr v-for="item in table" v-bind:key="item.id">
            <td>{{item.name}}</td>
            <td>{{item.lang}}</td>
            <td>{{item.phone}}</td>
        </tr>
    </tbody>
</template>

<<script>
export default {
  name: 'MissionList',
  data: function () {
      return {
          table: []
      }
  },
  beforeCreate: function () {
      
  }
}
</script>
